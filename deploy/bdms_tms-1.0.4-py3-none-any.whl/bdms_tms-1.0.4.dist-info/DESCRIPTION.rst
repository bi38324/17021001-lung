大数据管理系统之任务调度系统（Big Data Management System - Task Management System）
===================================================================================================


1. 安装
---------------------------------------------------------------------------------------------------

.. code-block:: bash

    $ git clone ssh://git@192.168.1.220:2222/og00/17020401_BDMS_TMS.git
    $ cd 17020401_BDMS_TMS
    $ python setup.py install

或者下载 安装包_

.. _安装包: http://192.168.1.220:8518/og00/17020401_BDMS_TMS/tags/

.. code-block:: bash

    $ pip install bdms_tms-0.0.1.zip

2. Quick Start
---------------------------------------------------------------------------------------------------

2.1 如何自定义算法？
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

第一步：在包bdms_tms.algorithms下建立以算法名称命名的模块，例如:bdms_tms.algorithms.k_means

第二步：实现算法的代码

.. code-block:: python

    # -*- coding: utf-8 -*-
    #
    # Created by lixing1611 on 17-4-25
    #
    from __future__ import absolute_import, unicode_literals
    from celery.utils.log import get_task_logger
    import pandas as pd
    from sklearn.cluster import KMeans as KM

    from bdms_tms.tms import app
    from bdms_tms.tms import TMS

    """
    K均值聚类
    """


    logger = get_task_logger(__name__)


    class KMeans(app.Task, TMS):

        __params__ = {
            'f': 'Item Data File',
        }

        def __init__(self):
            super(KMeans, self).__init__()

        def run(self, f):
            logger.info('运行K-Means算法: %s' % f.filename)
            self.connect()
            self.get_fs()
            try:
                f = self.fs.find_one({'filename': f})
                df = pd.read_excel(f)
                km = KM(n_clusters=2).fit(df)
                return km.labels_.tolist()
            finally:
                self.close()
    k_means = app.register_task(KMeans())


说明：

    1. app: 任务调度系统的应用实例
    2. TMS：任务调度系统基类，所有算法和流程必须继承自该基类

要点一：必须算法所在的类必须继承App.Task和TMS两个父类

要点二：算法类的构造方法必须显示调用父类的构造方法： ** super(KMeans, self).__init__() **

要点三：算法的逻辑必须写在run方法里面

要点四：可以通过 ** logger = get_task_logger(__name__) **，获取logger，进而记录算法运
行的日志

要点五：算法类有一个connect方法，调用这个方法，算法类的实例就获取了链接大数据平台数据库的能
力,这时算法类的实例就多了一个实例属性db，该实例属性为数据库连接对象，如果通过connec方法连接
到数据库，就必须显式调用close方法来关闭连接。

要点六：如果有用到数据集功能，可以调用get_fs方法，这时该算法类的实例就会多一个属性fs，为数据
集连接对象，可以通过fs.find_one来查询给定的数据集，返回一个文件句柄。

要点六：任何算法类必须有类属性__param__，是一个字典，键是在实例中要用到的参数，值是在web端
显示的名称

要点七：算法类实现后必须调用app.register_task方法类注册任务到任务调度系统

要点八：run方法的返回值必须是可json序列化的。（下文会有说明）

2.2 如何运行算法
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    from bdms_tms.algorithms.k_means import k_means

    k_means.delay('/algorithms/k-means/肺癌.xlsx')

为什么要通过delay方法运行而不是直接运行k_means？

因为web server的计算能力有限，要把这些计算任务分发到集群上运行，调用delay方法，we
b server并不真正执行任务，而是把任务放到任务调度系统里面去，集群上面运行的任务调度
系统会轮巡任务，并且运行，把结果放到任务调度系统的backend里面，这时我们的web serv
er就可以提取结果到页面上显示了。

这时一个很关键的一点是任务调度系统把结果放到backend里面是通过json序列化结果然后保
起来的，所以这就要求，任务的返回值一定要是可json序列化的，也就是说上面的那个KMeans
类的run方法的返回值一定要可以序列化（这个也是调用km.labels_.tolist())的原因，因
为km.labels_是一个ndarrary对象，不可json序列化。

那么如果判断一个对象是不是可json序列化的呢？

很简单，比如对象km.labels_:

.. code-block:: python

    import json

    json.dumps(km.labels_)

如果这时没有抛出异常就说明这个对象是可以json序列化的了，抛出异常的话说明这个不可json序列化
，必须转换。

3. 部署
---------------------------------------------------------------------------------------------------

3.1 任务调度系统的原理
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

大数据平台现在主要可分为4个模块，数据集、流程、算法、应用。

运行一个流程、算法、应用意味着要在集群上面运行一个程序（为什么要在集群上不是在web server上呢？因为这些流程、算法、应用一般都是CPU密集型或
着内存密集型程序，如果放到web server上运行，很影响web server的性能），由于这些程序又是非常耗时的，最好是能够一部处理，这样任务调度系统的
需求就来了。

一个任务调度系统因该满足以下需求：

    1. 有一个任务池（task pool）用来存取当前所有任务（待运行、正在运行、已运行）
    2. web server可以接收任务请求并添加到任务池
    3. 任务消费（task consumer）进程（可以有多个）读取任务池里面尚未运行的任务进行运行并且把任务结果放到任务后端（task backend）

总结来讲一个任务调度系统应该有以下基本部分：

    1. task pool（使用RabbitMQ实现）：存储所有任务
    2. task consumer（使用Celery Worker实现）：运行任务并把结果放到task backend
    3. task backend（使用redis实现）：保存任务结果

3.2 每个部件现在部署在哪里？
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

task pool用RabbitMQ实现，以docker形式部署在192.168.1.220上面，对应的Docker容器是：7c158327de49

task backend用Redis实现，以docker形式部署在192.168.1.220上面，对应的Docker容器是：fcdfb75683cd

task consumer以Celery Worker实现，部署在192.168.1.215上面，启动方式是：

.. code-block:: bash

    $ cd /export/home/lixing1611/celery-worker
    $ celery multi start celery-worker-1 -c 2 -A bdms_tms.tms:app

当更新了任务调度系统（TMS）时，task pool和task backend一般情况下不会更新，主要就是task consumer，当TMS的代码有更新时必须安装最新的TMS
包，并且重启celery worker才行，下面主要说明如何安装最新的TMS和怎么重启celery worker。

3.3 如何部署task consumer？
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

以下都是在192.168.1.215上运行的

1. 去GitLab：http://192.168.1.220:8518/og00/17020401_BDMS_TMS 下载最新的TMS安装包，例如：bdms_tms-0.0.1.zip

2. 安装TMS到anaconda:

    .. code-block:: bash

        $ /export/home/lixing1611/opt/gs/anaconda3/bin/pip install bdms_tms-0.0.1.zip

3. 关闭正在运行的celery worker

    .. code-block:: bash

        $ cd /export/home/lixing1611/celery-worker
        $ /export/home/lixing1611/opt/gs/anaconda3/bin/celery multi stop celery-worker-1

4. 运行新的celery worker

    .. code-block:: bash

        $ cd /export/home/lixing1611/celery-worker
        $ celery multi start celery-worker-1 -c 2 -A bdms_tms.tms:app


