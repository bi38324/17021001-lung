# -*- coding: utf-8 -*-
# created on 5/22/2017
# Author : Thomas
# Email  : tangyaohua1606@1gene.com.cn

import numpy as np
import re
import random
import copy
import json


class DataSet(object):
    '''save data into numpy ndarray'''
    def __init__(self,images,labels):
        assert len(images) == len(labels), (
            "images.shape: %s labels.shape: %s" % (len(images),
                                                   len(labels)))
        self._num_examples = len(images) #样本数量
        images = np.array(images)
        labels = np.array(labels)
        self._images = images
        self._labels = labels
        self._epochs_completed = 0
        self._index_in_epoch = 0
        self._rand = []
        #print(len(images), len(labels), sep='\t')

    @property
    def images(self):
        return self._images

    @property
    def labels(self):
        return self._labels

    @property
    def num_examples(self):
        return self._num_examples

    @property
    def epochs_completed(self):
        return self._epochs_completed

    def next_batch(self, batch_size):
        """Return the next `batch_size` examples from this data set."""

        start = self._index_in_epoch
        self._index_in_epoch += batch_size

        if self._index_in_epoch > self._num_examples:  #finish epoch
            self._epochs_completed += 1
            #shuffle the data
            perm = np.arange(self._num_examples)
            np.random.shuffle(perm)
            self._rand = list(perm)
            self._images = self._images[perm]
            self._labels = self._labels[perm]

            start = 0
            self._index_in_epoch = batch_size
            assert batch_size <= self._num_examples
        end = self._index_in_epoch
        return self._images[start:end], self._labels[start:end], self._rand[start:end]

def normalize(data, cnf):
    data = np.array(data).astype(float)
    with open(cnf, 'r') as f:
        cnf1 = json.load(f)

    index = cnf1['lung_cancer']['index']
    ranger = cnf1['lung_cancer']['range']
    gene = cnf1['lung_cancer']['gene']
    for i in range(gene[0], gene[1]):
        data[:, i] = data[:,i]/float(gene[2])
    for k, j in enumerate(index):
        data[:, j] = data[:, j]/float(ranger[k][1]-1)
    return data


def format(data, n_classes):
    #data = np.array(data)
    #data = nomalize(data, cnf)
    images = data[:, 1:]
    #print(images[0:5])
    lab = data[:, 0]
    labels = []
    for i in lab:
        a = [0 for j in range(n_classes)]
        a[int(i)] = 1
        b = copy.copy(a)
        labels.append(b)
    labels = np.array(labels)

    return images, labels

def format2(data, n_classes):
    #data = np.array(data)
    #data = np.loadtxt(file, dtype=int)
    #min_max_scaler = preprocessing.MinMaxScaler()
    #images = min_max_scaler.fit_transform(data[:, 1:])
    #images = preprocessing.scale(data[:, 1:])
    #data = nomalize(data, cnf)
    images = data[:, 1:]
    lab = data[:, 0]
    labels = np.ones([len(lab), n_classes], dtype=int)
    #images = np.mat(images)
    return images, labels






