# -*- coding: utf-8 -*-
# created on 9/21/2017
# Author : Thomas
# Email  : tangyaohua1606@1gene.com.cn
import json
import random as rd
import numpy as np

rank = '/home/gaobiyu/config/rank_100.json'

def report(sample, fig_data, cnf, web_page, avg_label, detect):
    index = cnf['lung_cancer']['index']
    imp = cnf['lung_cancer']['report']['重点建议']
    yang = cnf['lung_cancer']['report']['养生指南']
    figure = cnf['lung_cancer']['figure']
    score = fig_data[sample[index[0]]]
    score1 = int(score)

    #随机推送
    #=======================================
    xx = [0 for j in range(8)]
    xx[0] = rd.randint(0, len(imp['多补充健康饮食'])-1)  # Food_good(0.05)
    xx[1] = rd.randint(0, len(imp['拒绝非健康饮食'])-1)  # Food_bad(0.05)
    xx[2] = rd.randint(0, len(imp['运动规律培养'])-1)    # Sport(0.05)
    xx[3] = rd.randint(0, len(imp['隔离雾霾与污染'])-1)  # AQI(0.1)
    xx[4] = rd.randint(0, len(imp['保持良好室内环境'])-1)  # Job(0.1)

    xx[5] = rd.randint(0, len(yang['养生粥'])-1)  # 养生粥
    xx[6] = rd.randint(0, len(yang['茶饮'])-1)  # 茶饮
    xx[7] = rd.randint(0, len(yang['按摩保健'])-1)  # 按摩保健



    #基本信息
    #=======================================
    mm = {}
    mm['a'] = {'title':'您的患病指数', 'value': score1}
    #mm['您的患病指数'] = score1
    risk = ''
    if score1 <= 24:
        mm['b'] = {'title': '称号', 'value': '健康专家'}
        mm['c'] = {'title': '简评', 'value': '你的级别已经达到了健康专家的水平，恭喜亲，长命百岁不是问题！'}
        mm['d'] = {'title': '风险等级', 'value': '低风险'}
        # mm['称号'] = '健康专家'
        # mm['简评'] = '你的级别已经达到了健康专家的水平，恭喜亲，长命百岁不是问题！'
        # mm['风险等级'] = '低风险'
        risk = '低'
    elif score1 > 24 and score1 <= 32:
        mm['b'] = {'title': '称号', 'value': '健康大师'}
        mm['c'] = {'title': '简评', 'value': '传承师艺，你的生活方式已经比较健康，接近专业水平了哦，请继续保持良好习性！'}
        mm['d'] = {'title': '风险等级', 'value': '稍低风险'}
        # mm['称号'] = '健康大师'
        # mm['简评'] = '传承师艺，你的生活方式已经比较健康，接近专业水平了哦，请继续保持良好习性！'
        # mm['风险等级'] = '稍低风险'
        risk = '稍低'
    elif score1 > 32 and score1 <= 45:
        mm['b'] = {'title': '称号', 'value': '健康达人'}
        mm['c'] = {'title': '简评', 'value': '你是健康达人，还不错哦，已经达到平均水平了，再接再厉，对自己好点。'}
        mm['d'] = {'title': '风险等级', 'value': '正常风险'}

        # mm['称号'] = '健康达人'
        # mm['简评'] = '你是健康达人，还不错哦，已经达到平均水平了，再接再厉，对自己好点。'
        # mm['风险等级'] = '正常风险'
        risk = '正常'
    elif score1 > 45 and score1 <= 68.79:
        mm['b'] = {'title': '称号', 'value': '健康学徒'}
        mm['c'] = {'title': '简评', 'value': '健康学徒，你还有很大的进步空间，小心一不留神遭遇疾病的突袭。'}
        mm['d'] = {'title': '风险等级', 'value': '稍高风险'}
        # mm['称号'] = '健康学徒'
        # mm['简评'] = '健康学徒，你还有很大的进步空间，小心一不留神遭遇疾病的突袭。'
        # mm['风险等级'] = '稍高风险'
        risk = '稍高'
    elif score1 > 68.79 and score1 <= 95:
        mm['b'] = {'title': '称号', 'value': '健康菜鸟'}
        mm['c'] = {'title': '简评', 'value': '目前勉强保命，珍爱生命，请认真关注自己的健康。'}
        mm['d'] = {'title': '风险等级', 'value': '高风险'}

        # mm['称号'] = '健康菜鸟'
        # mm['简评'] = '目前勉强保命，珍爱生命，请认真关注自己的健康。'
        # mm['风险等级'] = '高风险'
        risk = '高'

    with open(rank, 'r') as f:
        his = json.load(f)

    for i in his.keys():
        his[i] = float(his[i])

    his[sample[0]] = score

    tmp = sorted(his.items(), key=lambda x: x[1])
    a = 0
    for i, j in enumerate(tmp):
        if j[0] == sample[0] and j[1] == score:
            a = i
        else:continue
    #print(a)
    rank_all = int(100*(len(tmp)-a)/len(tmp))

    # with open('rank.json', 'w') as ff:
    #     print(json.dumps(his, indent=4, ensure_ascii=False), file=ff)
    mm['e'] = {'title': '排名', 'value': a}
    #mm['排名'] = a
    b = '%d%%' % rank_all
    mm['f'] = {'title': '百分比', 'value': b}
    #mm['百分比'] = b

    c = '恭喜你获得了“%s”，你的肺癌患病指数是%d，排名第%d名，打败了%d%%的人群，风险%s。随着年龄增加，' \
        '肺癌风险也会有一段上升区间，请密切关注健康风险曲线，参照专家建议，定期体检，小心预防哦~' \
        % (mm['b']['value'], mm['a']['value'], mm['e']['value'], rank_all, risk)
    mm['g'] = {'title': '壹博士怎么说', 'value': c}
    #mm['壹博士怎么说'] = c

    web_page['detect_info'] = {'title':'检测信息', 'info':mm}



    #重点建议
    #===============================================
    mm1 = {}
    if not detect:
        mm1['a'] = {'title':'进行基因检测', 'value': '参与我们的基因检测，可以更精准地评估你的肺癌风险，针对性地制定健康管理方案，为您的健康保驾护航。'}
        #mm1['进行基因检测'] = '参与我们的基因检测，可以更精准地评估你的肺癌风险，针对性地制定健康管理方案，为您的健康保驾护航。'

    flag = 0
    #吸烟
    x = figure[0][1] - figure[0][0]
    y_samp = fig_data[flag:(flag + x)]
    y_avg = avg_label[flag:(flag + x)]
    y_true = sample[index[0]]
    #print('smoke', x, flag, y_samp)
    _y = int(100*(y_samp[y_true]-y_samp[0])/y_samp[y_true])
    _y_avg = int(100*(y_avg[y_true]-y_avg[0])/y_avg[y_true])
    if y_true >= 4 and _y > _y_avg:
        mm1['b'] = {'title': '吸烟习惯减少', 'value': '建议戒烟，戒烟最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)}
        #mm1['吸烟习惯减少'] = '建议戒烟，戒烟最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)
    elif y_true >= 4 and _y <= _y_avg and _y > 0:
        mm1['b'] = {'title': '吸烟习惯减少', 'value': '建议戒烟，戒烟最高能降低%d%%风险。' % _y}
        #mm1['吸烟习惯减少'] = '建议戒烟，戒烟最高能降低%d%%风险。' % _y
    elif y_true > 0 and y_true <= 3:
        mm1['b'] = {'title': '吸烟习惯减少', 'value': '建议戒烟'}
        #mm1['吸烟习惯减少'] = '建议戒烟。'
    elif y_true == 0:
        mm1['b'] = {'title': '吸烟习惯减少', 'value': '避免接触二手烟。'}
        #mm1['吸烟习惯减少'] = '避免接触二手烟。'
    flag += x

    #BMI指数
    x = figure[1][1] - figure[1][0]
    y_samp = fig_data[flag:(flag + x)]
    y_avg = avg_label[flag:(flag + x)]
    y_true = sample[index[1]]
    #print('BMI', x, flag, y_samp)

    _y = int(100*(y_samp[y_true]-y_samp[-1])/y_samp[y_true])
    _y_avg = int(100*(y_avg[y_true]-y_avg[-1])/y_avg[y_true])
    if y_true <= 1 and _y > _y_avg:
        mm1['c'] = {'title': '控制合理BMI', 'value': '适当增重，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)}
        #mm1['控制合理BMI'] = '适当增重，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)
    elif y_true <= 1 and _y <= _y_avg and _y > 0:
        mm1['c'] = {'title': '控制合理BMI', 'value': '适当增重，最高能降低%d%%风险。' % _y}
        #mm1['控制合理BMI'] = '适当增重，最高能降低%d%%风险。' % _y
    else:
        mm1['c'] = {'title': '控制合理BMI', 'value': '保持合理体重，保持良好锻炼习惯。'}
        #mm1['控制合理BMI'] = '保持合理体重，保持良好锻炼习惯。'
    flag += x

    #有益饮食
    x = figure[2][1] - figure[2][0]
    y_samp = fig_data[flag:(flag + x)]
    y_avg = avg_label[flag:(flag + x)]
    y_true = sample[index[2]]
    #print(y_samp)
    _y = int(100*(y_samp[y_true]-y_samp[-1])/y_samp[y_true])
    _y_avg = int(100*(y_avg[y_true]-y_avg[-1])/y_avg[y_true])
    if y_true <= 1 and _y > _y_avg:
        mm1['d'] = {'title': '多补充健康饮食', 'value': '多吃有益于防治肺癌的果蔬，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)}
        #mm1['多补充健康饮食'] = '多吃有益于防治肺癌的果蔬，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)
    elif y_true <= 1 and _y <= _y_avg  and _y > 0:
        mm1['d'] = {'title': '多补充健康饮食', 'value': '多吃有益于防治肺癌的果蔬，最高能降低%d%%风险。' % _y}
        #mm1['多补充健康饮食'] = '多吃有益于防治肺癌的果蔬，最高能降低%d%%风险。' % _y
    else:
        mm1['d'] = {'title': '多补充健康饮食', 'value': imp['多补充健康饮食'][xx[0]]}
        #mm1['多补充健康饮食'] = imp['多补充健康饮食'][xx[0]]
    flag += x

    #有害饮食
    x = figure[3][1] - figure[3][0]
    y_samp = fig_data[flag:(flag + x)]
    y_avg = avg_label[flag:(flag + x)]
    y_true = sample[index[3]]
    #print(y_samp)
    _y = int(100*(y_samp[y_true]-y_samp[0])/y_samp[y_true])
    _y_avg = int(100*(y_avg[y_true]-y_avg[0])/y_avg[y_true])
    if y_true >= 4 and _y > _y_avg:
        mm1['e'] = {'title': '拒绝非健康饮食', 'value': '少吃油炸、腌晒食品，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)}
        #mm1['拒绝非健康饮食'] = '少吃油炸、腌晒食品，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)
    elif y_true >= 4 and _y <= _y_avg and _y > 0:
        mm1['e'] = {'title': '拒绝非健康饮食', 'value': '少吃油炸、腌晒食品，最高能降低%d%%风险。' % _y}
        #mm1['拒绝非健康饮食'] = '少吃油炸、腌晒食品，最高能降低%d%%风险。' % _y
    else:
        mm1['e'] = {'title': '拒绝非健康饮食', 'value': imp['拒绝非健康饮食'][xx[1]]}
        #mm1['拒绝非健康饮食'] = imp['拒绝非健康饮食'][xx[1]]
    flag += x

    #运动指数
    x = figure[4][1] - figure[4][0]
    y_samp = fig_data[flag:(flag + x)]
    y_avg = avg_label[flag:(flag + x)]
    y_true = sample[index[4]]
    #print(y_samp)
    _y = int(100*(y_samp[y_true]-y_samp[-1])/y_samp[y_true])
    _y_avg = int(100*(y_avg[y_true]-y_avg[-1])/y_avg[y_true])
    if y_true <= 1 and _y > _y_avg:
        mm1['f'] = {'title': '运动规律培养', 'value': '增强运动，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)}
        #mm1['运动规律培养'] = '增强运动，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)
    elif y_true <= 1 and _y <= _y_avg:
        mm1['f'] = {'title': '运动规律培养', 'value': '增强运动，最高能降低%d%%风险。' % _y}
        #mm1['运动规律培养'] = '增强运动，最高能降低%d%%风险。' % _y
    else:
        mm1['f'] = {'title': '运动规律培养', 'value': imp['运动规律培养'][xx[2]]}
        #mm1['运动规律培养'] = imp['运动规律培养'][xx[2]]
    flag += x

    #空气质量指数
    x = figure[5][1] - figure[5][0]
    y_samp = fig_data[flag:(flag + x)]
    y_avg = avg_label[flag:(flag + x)]
    y_true = sample[index[5]]
    #print(y_samp)
    _y = int(100*(y_samp[y_true]-y_samp[0])/y_samp[y_true])
    _y_avg = int(100*(y_avg[y_true]-y_avg[0])/y_avg[y_true])
    if y_true >= 3 and _y > _y_avg:
        mm1['g'] = {'title': '隔离雾霾与污染', 'value': '隔离雾霾与污染，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)}
        #mm1['隔离雾霾与污染'] = '隔离雾霾与污染，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)
    elif y_true >= 3 and _y <= _y_avg and _y > 0:
        mm1['g'] = {'title': '隔离雾霾与污染', 'value': '隔离雾霾与污染，最高能降低%d%%风险。' % _y}
        #mm1['隔离雾霾与污染'] = '隔离雾霾与污染，最高能降低%d%%风险。' % _y
    else:
        mm1['g'] = {'title': '隔离雾霾与污染', 'value': imp['隔离雾霾与污染'][xx[3]]}
        # mm1['隔离雾霾与污染'] = imp['隔离雾霾与污染'][xx[3]]
    flag += x

    #职业接触
    x = figure[6][1] - figure[6][0]
    y_samp = fig_data[flag:(flag + x)]
    y_avg = avg_label[flag:(flag + x)]
    y_true = sample[index[6]]
    #print(y_samp)
    _y = int(100*(y_samp[y_true]-y_samp[0])/y_samp[y_true])
    _y_avg = int(100*(y_avg[y_true]-y_avg[0])/y_avg[y_true])
    if y_true >= 4 and _y > _y_avg:
        mm1['h'] = {'title': '保持良好室内环境', 'value': '远离肺癌高危职业，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)}
        #mm1['保持良好室内环境'] = '远离肺癌高危职业，最高能降低%d%%风险，比人群平均显著%d%%。' % (_y, _y-_y_avg)
    elif y_true >= 4 and _y <= _y_avg and _y > 0:
        mm1['h'] = {'title': '保持良好室内环境', 'value': '远离肺癌高危职业，最高能降低%d%%风险。' % _y}
        #mm1['保持良好室内环境'] = '远离肺癌高危职业，最高能降低%d%%风险。' % _y
    else:
        mm1['h'] = {'title': '保持良好室内环境', 'value': imp['保持良好室内环境'][xx[4]]}
        #mm1['保持良好室内环境'] = imp['保持良好室内环境'][xx[4]]
    flag += x

    web_page['advise_info'] = {'title':'重点建议', 'info': mm1}



    #养生指南
    #===============================================
    mm2 = {}
    mm2['a'] = {'title': '养生粥', 'info': {'title':list(yang['养生粥'].keys())[xx[5]], 'value': yang['养生粥'][list(yang['养生粥'].keys())[xx[5]]]}}
    mm2['b'] = {'title': '茶饮', 'info': {'title':list(yang['茶饮'].keys())[xx[6]], 'value': yang['茶饮'][list(yang['茶饮'].keys())[xx[6]]]}}
    mm2['c'] = {'title': '按摩保健', 'info': {'title':list(yang['按摩保健'].keys())[xx[7]], 'value': yang['按摩保健'][list(yang['按摩保健'].keys())[xx[7]]]}}

    #mm2['养生粥'] = {list(yang['养生粥'].keys())[xx[5]]: yang['养生粥'][list(yang['养生粥'].keys())[xx[5]]]}
    #mm2['茶饮'] = {list(yang['茶饮'].keys())[xx[6]]: yang['茶饮'][list(yang['茶饮'].keys())[xx[6]]]}
    #mm2['按摩保健'] = {list(yang['按摩保健'].keys())[xx[7]]: yang['按摩保健'][list(yang['按摩保健'].keys())[xx[7]]]}

    web_page['health_info'] = {'title': '养生指南', 'info': mm2}
    #web_page['养生指南'] = mm2

    return web_page
