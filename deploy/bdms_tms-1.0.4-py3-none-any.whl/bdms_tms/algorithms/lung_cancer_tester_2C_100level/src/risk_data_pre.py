# -*- coding: utf-8 -*-
# created on 8/2/2017
# Author : Thomas
# Email  : tangyaohua1606@1gene.com.cn


import numpy as np
import os
import re
import copy



class Data_pre(object):
    '''根据不同的生活因素，生成相应的数据；固定其他，改变一项，从0到5档；因素包含吸烟、BMI、职业、运动、PM2.5、饮食'''
    def __init__(self, sample, index, ranger):
        self._sample = sample
        self._index = index
        self._ranger = ranger


    @property
    def sample(self):
        return self._sample

    @property
    def index(self):
        return self._index

    @property
    def ranger(self):
        return self._ranger


    def dataset(self):
        #tmp = [self._sample for i in range(30)]
        res = []
        for k, i in enumerate(self._index):
            for j in range(self._ranger[k][0], self._ranger[k][1]):
                tmp = copy.deepcopy(self._sample)
                tmp[i] = j
                tmp2 = copy.deepcopy(tmp)
                res.append(tmp2)
        res = np.array(res)
        return res


class Background_level(object):
    '''提取生活因素背景（平均）数据'''
    def __init__(self, index, ranger, path, accuracy=0.82):
        self._index = index   #生活因素下标
        self._range = ranger  #每一项因素范围
        self._dir = path      #模型保存路径
        self._acc = accuracy  #模型正确率

    @property
    def index(self):
        return self._index

    @property
    def range(self):
        return self._range

    @property
    def dir(self):
        return self._dir

    @property
    def acc(self):
        return self._acc


    def search_model(self, dirs):
        good_model = []
        for model in os.listdir(dirs):
            fp = os.path.join(dirs, model)
            if os.path.isfile(fp):
                m = re.search(r'^(model-\d+-acc-(0\.\d{4}))\.index$', model)

                if m is None:
                    continue
                elif float(m.group(2)) >= self._acc:
                    dd = os.path.join(dirs, m.group(1))
                    good_model.append(dd)
                    #print(model)
            elif os.path.isdir(fp):
                self.search_model(fp)
        return good_model

    def search_model2(self):
        good_model = []
        for model in os.listdir(self._dir):
            fp = os.path.join(self._dir, model)
            for dd in os.listdir(fp):
                m = re.search(r'^(model-\d+-acc-(0\.\d{4}))\.index$', dd)
                if m is None:
                    continue
                elif float(m.group(2)) >= self._acc:
                    dd = os.path.join(fp, m.group(1))
                    good_model.append(dd)
                    #print(model)
        return good_model

    def setdata(self, data, label, factor):

        cen = {}
        for i, j in enumerate(self._index):
            mm = []
            for k in range(self._range[i][0], self._range[i][1]):
                tmp = label[data[:, j-1] == k]
                tmp2 = np.mean(tmp)
                mm.append(tmp2)
            cen[factor[i]] = mm[0:]
        return cen









