# -*- coding: utf-8 -*-
"""
Created on Fri Sep  8 09:52:13 2017

@author: Administrator
"""

import numpy as np
from collections import defaultdict
import xlrd
import json
import sys
from math import *

data = xlrd.open_workbook('aqi.xlsx')

table = data.sheet_by_name('List')

nrow = table.nrows

city = defaultdict(list)
for line in range(1,nrow):
    tmp = table.row_values(line)
    #da = tmp[1].decode('gbk').encode('utf-8')
    city[tmp[1]] += [tmp[3]]

out = {}
for name in sorted(city.keys()):
    t = city[name]
    tt = [float(i) for i in t]
    la = np.mean(tt)
    out[name] = int(round(la))

with open('city.JSON', 'w') as f:
    json.dump(out, f, indent=1, sort_keys=True, ensure_ascii=False)



