# -*- coding: utf-8 -*-
#
# Created by lixing1611 on 17-4-5
#
from __future__ import absolute_import, unicode_literals


try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus


"""
celery settings module
"""

# mongodb settings
mongo_host = '192.168.11.12'
mongo_user = 'bdmser'
mongo_password = '1gene-bdmser'
mongo_db = 'bdms'
mongodb_uri = 'mongodb://%s:%s@%s/%s' % (quote_plus(mongo_user), quote_plus(mongo_password), mongo_host, mongo_db)

# broker settings
broker_url = 'amqp://bdmser:1gene-bdmser@192.168.1.220//'

# backend
result_backend = 'redis://192.168.1.220:3012/0'

# preload modules
include = [
    'bdms_tms.algorithm.lung_cancer_tester_2C_100level.lung_cancer'
]

# time settings
enable_utc = True
timezone = 'Asia/Shanghai'

# 集群上dataset存放的路径
dataset_path = '/p299/user/og00/lixing1611/tms/dataset'
