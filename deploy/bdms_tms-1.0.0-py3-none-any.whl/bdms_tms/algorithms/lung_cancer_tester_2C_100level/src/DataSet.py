# -*- coding: utf-8 -*-
# created on 5/22/2017
# Author : Thomas
# Email  : tangyaohua1606@1gene.com.cn

from sklearn import preprocessing
import numpy as np
import pymongo
import xlrd
import re
import random
import copy
import json


class DataSet(object):
    '''save data into numpy ndarray'''
    def __init__(self,images,labels):
        assert len(images) == len(labels), (
            "images.shape: %s labels.shape: %s" % (len(images),
                                                   len(labels)))
        self._num_examples = len(images) #样本数量
        images = np.array(images)
        labels = np.array(labels)
        self._images = images
        self._labels = labels
        self._epochs_completed = 0
        self._index_in_epoch = 0
        self._rand = []
        #print(len(images), len(labels), sep='\t')

    @property
    def images(self):
        return self._images

    @property
    def labels(self):
        return self._labels

    @property
    def num_examples(self):
        return self._num_examples

    @property
    def epochs_completed(self):
        return self._epochs_completed

    def next_batch(self, batch_size):
        """Return the next `batch_size` examples from this data set."""

        start = self._index_in_epoch
        self._index_in_epoch += batch_size

        if self._index_in_epoch > self._num_examples:  #finish epoch
            self._epochs_completed += 1
            #shuffle the data
            perm = np.arange(self._num_examples)
            np.random.shuffle(perm)
            self._rand = list(perm)
            self._images = self._images[perm]
            self._labels = self._labels[perm]

            start = 0
            self._index_in_epoch = batch_size
            assert batch_size <= self._num_examples
        end = self._index_in_epoch
        return self._images[start:end], self._labels[start:end], self._rand[start:end]

def normalize(data, cnf):
    data = np.array(data).astype(float)
    with open(cnf, 'r') as f:
        cnf1 = json.load(f)

    index = cnf1['lung_cancer']['index']
    ranger = cnf1['lung_cancer']['range']
    gene = cnf1['lung_cancer']['gene']
    for i in range(gene[0], gene[1]):
        data[:, i] = data[:,i]/float(gene[2])
    for k, j in enumerate(index):
        data[:, j] = data[:, j]/float(ranger[k][1]-1)
    return data


def format(data, n_classes):
    #data = np.array(data)
    #data = nomalize(data, cnf)
    images = data[:, 1:]
    #print(images[0:5])
    lab = data[:, 0]
    labels = []
    for i in lab:
        a = [0 for j in range(n_classes)]
        a[int(i)] = 1
        b = copy.copy(a)
        labels.append(b)
    labels = np.array(labels)

    return images, labels

def format2(data, n_classes):
    #data = np.array(data)
    #data = np.loadtxt(file, dtype=int)
    #min_max_scaler = preprocessing.MinMaxScaler()
    #images = min_max_scaler.fit_transform(data[:, 1:])
    #images = preprocessing.scale(data[:, 1:])
    #data = nomalize(data, cnf)
    images = data[:, 1:]
    lab = data[:, 0]
    labels = np.ones([len(lab), n_classes], dtype=int)
    #images = np.mat(images)
    return images, labels



def data_pre(file, disease):
    ''' 从excel中提取样本的基因型信息，并根据ref和alt转换成0，1，2 '''

    data = xlrd.open_workbook(file)

    table1 = data.sheet_by_name('基因型信息')
    table2 = data.sheet_by_name('详细基因型')

    ref = table1.col_values(13)     #ref genotype
    alt = table1.col_values(14)     #alt genotype
    norm = table1.col_values(15)    #normal genotype
    typ = table1.col_values(3)

    res = []
    name = {}
    for i in range(2,table2.ncols):
        tmp = []
        name[i-2] = int(table2.col_values(i)[0])
        for j in range(1,table2.nrows):
            if norm[j] == '--':
                continue
            if typ[j] == disease:
                test = table2.col_values(i)[j]
                if test == '--' or test == 'NN':
                    test = norm[j]
                if test == ref[j]+ref[j]:
                    tmp.append(0)
                elif test == ref[j]+alt[j] or test == alt[j]+ref[j]:
                    tmp.append(1)
                elif test == alt[j]+alt[j]:
                    tmp.append(2)
                else:
                    tmp.append(-1)
                    #print(i, j, norm[j], test, sep='\t')
            else: continue
        res.append(tmp)
        tmp = []
    #print(res[0])
    return res, name


def factor(file, name):
    data = xlrd.open_workbook(file)
    table = data.sheet_by_name('其他因素')
    key = name.keys()
    res = []
    for i in key:
        tmp = []
        for j in range(1, table.nrows):
            k = random.randint(0,1)
            tmp.append(k)

        res.append(tmp)
        tmp = []
    print(res[0])
    return res


def Bdarray(argv):
    key = []
    value = []
    for line in open(argv,'r'):
        line = line.strip()
        if (re.match('^ID',line[0])): continue
        line2 = re.split('\t', line)
        t = []

        #==========================
        #Cancer => [1,0]
        #Ck     => [0,1]
        #==========================
        if (re.match('^HC', line2[0])):
            t = [0,1]
        else:
            t = [1,0]
        key.append(line2[1:])
        value.append(t)
    return (key,value)


class DataSets(object):
    pass



def bdms(disease):
    '''
    提取数据库中真实样本的基因型，并根据ref和alt转换成0，1，2
    返回res为一个字典，key：样本号
    '''


    client = pymongo.MongoClient('192.168.11.12')
    db = client.get_database('bdms')
    db.authenticate('bdmser', '1gene-bdmser')
    print('Connect to the DataBase, Done')
    res = {}
    sample = db.ov_detection_result.find()
    disease = db.ov_item.find_one({'name': disease})
    tmp = []
    recoder = {}
    for gene in disease['alleles']:
        anno = db.axiom_pmra_anno.find({'affy_snp_id' : gene['og_id']})
        rs = anno[0]['dbsnp_rs_id']
        ref = anno[0]['ref_allele']
        alt = anno[0]['alt_allele']
        recoder[rs] = [ref,alt]
        print(rs,ref,alt,sep='\t')
        for j in range(len(sample[0]['sample_results'])):
            if rs == sample[0]['sample_results'][j]['og_id']:
                tmp.append(j)
                print(j)
            else:
                continue

    for i in range(10):
        tmp2 = []
        for j in tmp:
            test = sample[i]['sample_results'][j]['genotype']
            rs2 = sample[i]['sample_results'][j]['og_id']
            print(test, recoder[rs2][0], recoder[rs2][1])
            if test == recoder[rs2][0] + recoder[rs2][0]:
                tmp2.append(0)
            elif test == recoder[rs2][0] + recoder[rs2][1] or test == recoder[rs2][1] + recoder[rs2][0]:
                tmp2.append(1)
            elif test == recoder[rs2][1] + recoder[rs2][1]:
                tmp2.append(2)
            else:
                tmp2.append(-1)
        res[sample[i]['sample_id']] = tmp2
    return res



