# -*- coding: utf-8 -*-
# created on 7/11/2017
# Author : Thomas
# Email  : tangyaohua1606@1gene.com.cn

import os
import sys
import tensorflow as tf
import numpy as np
import time
import json
import copy
import src.DataSet as ds

# Create model
def multilayer_perceptron(x, weights, biases):
    # Hidden layer with RELU activation
    layer_1 = tf.add(tf.matmul(x, weights['h1']), biases['b1'])
    layer_1 = tf.nn.sigmoid(layer_1)
    # Hidden layer with RELU activation
    layer_2 = tf.add(tf.matmul(layer_1, weights['h2']), biases['b2'])
    layer_2 = tf.nn.sigmoid(layer_2)
    # Hidden layer with RELU activation
    layer_3 = tf.add(tf.matmul(layer_2, weights['h3']), biases['b3'])
    layer_3 = tf.nn.sigmoid(layer_3)

    # Output layer with linear activation
    out_layer = tf.matmul(layer_3, weights['out']) + biases['out']
    return out_layer


def data_change(svm, cyc, r, n_classes, cnf):
    svm1 = np.array(svm)
    svm1[:, cyc] = r
    #print(*svm1[0, 22:],sep='\t')
    svm1 = ds.normalize(svm1, cnf)
    (train_file, train_label) = ds.format(svm1, n_classes)
    #print(*train_file[0, 22:], sep='\t')
    s = ds.DataSet(train_file, train_label)
    return s

def final(f):
    tmp = []
    for i in f:
        tmp.append(i.argmax())
    return np.mean(tmp)

def mlp(learning_rate=0.01,
        training_epochs=150,
        batch_size=100,
        n_hidden_1=50,
        n_hidden_2=30,
        n_hidden_3=15,
        n_input=34,
        n_classes=100,
        train_data='',
        test_data='',
        model_path='',
        model_acc='',
        cnf='/lustre/project/og00/tangyaohua/1gene2017/02.python/python_learning/TMS/lung_cancer/config.json',
        is_train=True,
        n_model=0,
        svm2=''):

    with tf.Graph().as_default():
        #load json
        with open(cnf, 'r') as f:
            cnf1 = json.load(f)
        index = cnf1['lung_cancer']['index']
        ranger = cnf1['lung_cancer']['range']

        # tf Graph input
        x = tf.placeholder(tf.float32, [None, n_input])  # 输入数据占位符
        y = tf.placeholder(tf.float32, [None, n_classes])  # 输出数据站位符，one-hot为10维
        keep_prob = tf.placeholder(tf.float32)
        # Store layers weight & bias
        weights = {
            'h1': tf.Variable(tf.random_normal([n_input, n_hidden_1])),
            'h2': tf.Variable(tf.random_normal([n_hidden_1, n_hidden_2])),
            'h3': tf.Variable(tf.random_normal([n_hidden_2, n_hidden_3])),
            'out': tf.Variable(tf.random_normal([n_hidden_3, n_classes]))
        }
        biases = {
            'b1': tf.Variable(tf.random_normal([n_hidden_1])),
            'b2': tf.Variable(tf.random_normal([n_hidden_2])),
            'b3': tf.Variable(tf.random_normal([n_hidden_3])),
            'out': tf.Variable(tf.random_normal([n_classes]))
        }

        # Construct model 主模型
        pred= multilayer_perceptron(x, weights, biases)
        pred = tf.nn.dropout(pred, keep_prob)

        # Test model
        correct_prediction = tf.equal(tf.argmax(pred, 1), tf.argmax(y, 1))
        with tf.name_scope('Accuracy'):
            # Calculate accuracy
            accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))
            #tf.summary.scalar('Accuracy', accuracy)

        saver = tf.train.Saver(max_to_keep=10000)

        # Define loss and optimizer
        with tf.name_scope('loss'):
            lost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=pred, labels=y))  # 交叉熵
            #tf.summary.scalar('lost', lost)
        with tf.name_scope('train'):
            optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(lost)

        # Initializing the variables
        # init = tf.global_variables_initializer()  # 初始化变量
        init = tf.global_variables_initializer()
        # Launch the graph
        with tf.Session() as sess:
            sess.run(init)
            #merged = tf.summary.merge_all()
            #writer = tf.summary.FileWriter('./result/logdir', sess.graph)
            if is_train:
                sess.run(init)
                # Training cycle
                for epoch in range(training_epochs):
                    # summary_str = sess.run(summary_op)
                    # summary_writer.add_summary(summary_str, epoch)
                    avg_cost = 0.
                    acc = 0.
                    total_batch = int(train_data.num_examples / batch_size)
                    # Loop over all batches
                    for i in range(total_batch):
                        batch_x, batch_y, perm = train_data.next_batch(batch_size)
                        # Run optimization op (backprop) and cost op (to get loss value)
                        _, c, acc = sess.run([optimizer, lost, accuracy], feed_dict={x: batch_x,
                                                                                     y: batch_y,
                                                                                     keep_prob: 0.9})
                        # Compute average loss
                        avg_cost += c / total_batch
                    if epoch%10 == 0:
                        print("Epoch:", '%04d' % (epoch%training_epochs + 1), \
                              "cost=", "{:.9f}".format(avg_cost), "Accuracy:", '%0.4f'% acc)

                aa, ac = sess.run([pred, accuracy], feed_dict={x: test_data.images, y: test_data.labels, keep_prob: 1})
                gg = sess.run(tf.nn.relu(aa))
                fff = sess.run(tf.nn.softmax(gg))
                for k in range(len(test_data.labels)):
                    c = test_data.labels[k]
                    d = fff[k]
                    print(c.argmax(), d.argmax(), max(gg[k]) / sum(gg[k]), sep='\t')
                print('Accuracy:', ac)
                #print("Accuracy:", '%0.4f'% ac)
                m2 = ('model-%05d-acc-%.4f') % (n_model, ac)
                model_path1 = os.path.join(model_path, m2)
                save_path = saver.save(sess, model_path1)

                #save model path
                out = '%s/modeldir_acc-og00.xls' % model_path
                f = open(out, 'a')
                print(save_path, ac, sep='\t', file=f)
                f.close()

                # calculate avg
                if float(ac) >= model_acc:
                    lab = []
                    for i, cyc in enumerate(index):
                        for r in range(ranger[i][0], ranger[i][1]):
                            samp = data_change(svm2, cyc, r, n_classes, cnf)
                            e = sess.run(pred, feed_dict={x: samp.images, y: samp.labels, keep_prob: 1})
                            g = sess.run(tf.nn.relu(e))
                            f = sess.run(tf.nn.softmax(g))
                            d = final(f)
                            lab.append(d)
                    bac = '%s/back_avg-og00.txt' % model_path
                    ff = open(bac, 'a')
                    print(*lab, sep='\t', file=ff)
                    ff.close()
                sys.stdout.flush()
                sess.run(init)
                return ac

            else:
                sess.run(init)
                saver.restore(sess, model_path)
                e = sess.run(pred, feed_dict={x: test_data.images, y: test_data.labels, keep_prob: 1})
                g = sess.run(tf.nn.relu(e))
                f = sess.run(tf.nn.softmax(g))

                res = [i.argmax() for i in f]
                return res


