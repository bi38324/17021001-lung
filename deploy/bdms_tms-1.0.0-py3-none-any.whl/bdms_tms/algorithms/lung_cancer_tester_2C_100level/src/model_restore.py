# -*- coding: utf-8 -*-
# created on 5/16/2017
# Author : Thomas
# Email  : tangyaohua1606@1gene.com.cn
import tensorflow as tf


def mlp(svm, model_path):
    with tf.Graph().as_default():
        # Network Parameters
        n_hidden_1 = 50  # 1st layer number of features
        n_hidden_2 = 30  # 2nd layer number of features
        n_hidden_3 = 15  # 2nd layer number of features
        n_classes = 100   # Data total classes (0-9 digits)
        n_input = len(svm.images[0])    # MNIST data input (img shape: 28*28)


        # tf Graph input
        x = tf.placeholder("float", [None, n_input])    # 输入数据占位符
        y = tf.placeholder("float", [None, n_classes])  # 输出数据站位符，one-hot为10维


        # Create model
        def multilayer_perceptron(x, weights, biases):
            # Hidden layer with RELU activation
            layer_1 = tf.add(tf.matmul(x, weights['h1']), biases['b1'])
            layer_1 = tf.nn.relu(layer_1)
            # Hidden layer with RELU activation
            layer_2 = tf.add(tf.matmul(layer_1, weights['h2']), biases['b2'])
            layer_2 = tf.nn.relu(layer_2)
            #
            layer_3 = tf.add(tf.matmul(layer_2, weights['h3']), biases['b3'])
            layer_3 = tf.nn.relu(layer_3)

            # Output layer with linear activation
            out_layer = tf.matmul(layer_3, weights['out']) + biases['out']
            return out_layer

        # Store layers weight & bias
        weights = {
            'h1': tf.Variable(tf.random_normal([n_input, n_hidden_1])),
            'h2': tf.Variable(tf.random_normal([n_hidden_1, n_hidden_2])),
            'h3': tf.Variable(tf.random_normal([n_hidden_2, n_hidden_3])),
            'out': tf.Variable(tf.random_normal([n_hidden_3, n_classes]))
        }
        biases = {
            'b1': tf.Variable(tf.random_normal([n_hidden_1])),
            'b2': tf.Variable(tf.random_normal([n_hidden_2])),
            'b3': tf.Variable(tf.random_normal([n_hidden_3])),
            'out': tf.Variable(tf.random_normal([n_classes]))
        }
        # Construct model 主模型
        pred = multilayer_perceptron(x, weights, biases)
        saver = tf.train.Saver()

        # Test model
        correct_prediction = tf.equal(tf.argmax(pred, 1), tf.argmax(y, 1))
        with tf.name_scope('Accuracy'):
            # Calculate accuracy
            accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))



        with tf.Session() as sess:
            #sess.run(init)
            #new_saver = tf.train.import_meta_graph(mm)

            #new_saver.restore(sess, tf.train.latest_checkpoint('model_dir/GH-default_lr_0.01-20170808-145336/'))
            saver.restore(sess, model_path)
            #correct_prediction = tf.equal(tf.argmax(pred, 1), tf.argmax(y, 1))
            # Calculate accuracy
            #accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))
            #print("Accuracy:", accuracy.eval({x: svm.images, y: svm.labels}))

            # Using the model to predict test data
            e = sess.run(pred, feed_dict={x: svm.images, y: svm.labels})
            g = sess.run(tf.nn.relu(e))
            f = sess.run(tf.nn.softmax(g))

            res = [i.argmax() for i in f]
            return res





