# -*- coding: utf-8 -*-
#
# Created by lixing1611 on 17-4-5
#
from __future__ import absolute_import, unicode_literals

from celery import Celery
import pymongo
import gridfs


"""
Celery App file
"""

app = Celery('tms')
app.config_from_object('bdms_tms.settings')


class TMS(object):
    """
    Task Management System Base Class
    """
    def __init__(self):
        self.client = None
        self.db = None
        self.fs = None

    def connect(self):
        """
        connect database
        :return: db connection
        """
        self.client = pymongo.MongoClient(app.conf.get('mongodb_uri'))
        self.db = self.client.get_database(app.conf.get('mongo_db'))
        return self.db

    def get_fs(self):
        self.fs = gridfs.GridFS(self.db)
        return self.fs

    def close(self):
        self.client.close()
