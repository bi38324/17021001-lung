# -*- coding: utf-8 -*-
# created on 8/2/2017
# Author : Thomas
# Email  : tangyaohua1606@1gene.com.cn

import sys, os, time, random
from celery.utils.log import get_task_logger
import numpy as np
import json
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.font_manager as mf
import bdms_tms.algorithms.lung_cancer_tester_2C_100level.src.DataSet as ds
import bdms_tms.algorithms.lung_cancer_tester_2C_100level.src.risk_data_pre as rdp
import bdms_tms.algorithms.lung_cancer_tester_2C_100level.src.model as md
import bdms_tms.algorithms.lung_cancer_tester_2C_100level.src.report as report
#import scipy.stats as stats

# 设置中文字体
#mpl.rcParams['font.sans-serif'] = ['SimHei']
#plt.style.use('ggplot')
mpl.rc('xtick', labelsize=14, color = 'aqua')
mpl.rc('ytick', labelsize=14, color = 'aqua')
mpl.rc('axes', labelsize=18)
mpl.rcParams['xtick.direction'] = 'in'
mpl.rcParams['ytick.direction'] = 'out'
mpl.rcParams['axes.labelsize'] = 'large'
logger = get_task_logger(__name__)
#zhfont = mf.FontProperties(fname='/usr/share/fonts/cjkuni-ukai/ukai.ttc')
zhfont = mf.FontProperties(fname='/usr/share/fonts/cjkuni-uming/uming.ttc')
def set_aex(ax):
    ax.spines['bottom'].set_linewidth(3)
    ax.spines['bottom'].set_color('aqua')
    ax.spines['left'].set_linewidth(3)
    ax.spines['left'].set_color('aqua')
    ax.spines['top'].set_linewidth(3)
    ax.spines['top'].set_color('aqua')
    ax.spines['right'].set_linewidth(3)
    ax.spines['right'].set_color('aqua')
    ax.xaxis.set_ticks_position('none')
    ax.yaxis.set_ticks_position('none')
    return ax


def main(testfile='',
         model_path='',
         cnf='/home/gaobiyu/config/config.json',
         model_acc=0,
         sample_ID='',
         n_class=100,
         detect=False):

    mm = {}
    #load config file
    #==========================
    with open(cnf, 'r') as f:
        cnf1 = json.load(f)
    index = cnf1['lung_cancer']['index']
    ranger = cnf1['lung_cancer']['range']
    factor = cnf1['lung_cancer']['detail']
    figure = cnf1['lung_cancer']['figure']
    factor2 = cnf1['lung_cancer']['en_name']

    avg_label = '%s/back_avg-og00.txt' % model_path
    avg_label = np.mean(np.loadtxt(avg_label, dtype=float), axis=0).reshape((-1,1))

    model_dir = '%s/modeldir_acc-og00.xls' % model_path

    model_dir = [line.strip().split('\t') for line in open(model_dir, 'r')]
    model_path2 = []
    for k in model_dir:
        if float(k[1]) >= model_acc:
            model_path2.append(k[0])

    # result path
    a = '/home/gaobiyu/result'
    hyper_parameter_str = 'LungCancer' + '_acc_' + str(model_acc)
    output = '%s/figure/GH-%s-%s' % (
        a,
        hyper_parameter_str,
        time.strftime("%Y%m%d-%H%M%S")
    )

    if not os.path.exists(output): os.makedirs(output)
    #fig_data_back = []

    sample = testfile
    sample[0] = 0
    res = rdp.Data_pre(sample, index, ranger)
    #print(len(testfile), sample)
    tmp = res.dataset()
    tmp = ds.normalize(tmp, cnf)
    #print(*tmp[0],sep='\t')
    (da, label1) = ds.format2(tmp, n_class)

    #label1 = np.ones([len(tmp), 5], dtype=int)
    svm = ds.DataSet(da, label1)
    #print(*svm.images[0], sep='\t')
    #print(*svm.images, sep='\n')
    #print('Save data into numpy dbarray, done!')
    res = []
    for i in model_path2:
        fig = md.mlp(
            learning_rate=0.01,
            training_epochs=150,
            batch_size=100,
            n_hidden_1=50,
            n_hidden_2=30,
            n_hidden_3=15,
            n_input=len(svm.images[0]),
            n_classes=n_class,
            test_data=svm,
            model_path=i,
            model_acc=model_acc,
            is_train=False)
        res.append(fig)
    fig_data =np.mean(res, axis=0)


    # 吸烟、BMI、职业、运动、PM2.5、饮食
    flag = 0
    image = {}
    for i, j in enumerate(factor2):
        #x轴范围
        #===================================
        x = [k for k in range(figure[i][0], figure[i][1], figure[i][2])]

        #y轴范围
        #===================================
        y_samp = fig_data[flag:(flag + len(x))]
        y_avg = avg_label[flag:(flag + len(x))]

        #y_samp = [(22.5*i+5) for i in y_samp]
        #y_avg = [(22.5*i+5) for i in y_avg]

        # 未参与基因检测的区间（±15%）
        #===================================
        add = (np.mean(y_samp))*0.15
        y_samp_low = [i-add for i in y_samp]
        y_samp_up = [i+add for i in y_samp]

        # 开始画图
        #===================================
        aex = plt.figure(figsize=(10, 8))
        aex.patch.set_alpha(0)     # 设置背景透明度
        ax = aex.add_subplot(111)
        ax = set_aex(ax)

        y_index = flag + int(sample[index[i]]) - ranger[i][0]

        if not detect:
            ax.fill_between(x, y_samp_low, y_samp_up, alpha=0.3, color='grey')

        ax.plot(x, y_avg, color='aqua', linestyle='--', label='人群平均值', linewidth=3.0)
        ax.plot(x, y_samp, color='aqua', label='您的患病指数', linewidth=3.0)
        #ax.scatter(x[sample[index[i]]- ranger[i][0]], 22.5*fig_data[y_index]+5, s=60, label='您的真实值', c='orange', zorder=10)
        ax.scatter(x[sample[index[i]] - ranger[i][0]], fig_data[y_index], s=60, label='您的真实值', c='orange', zorder=10)

        ax.set_xlim(figure[i][0], figure[i][1]-1)
        ax.set_ylim(0, 100)
        if j == '年龄':
            ax.set_xticklabels(('≤20', '30', '40', '50', '60', '70', '≥80'), fontsize=16)

        ax.set_ylabel('患病指数', fontsize=18, fontproperties=zhfont, color='w')
        ax.set_xlabel(str(factor[i]), fontsize=18, fontproperties=zhfont, color='w')
        ax.yaxis.grid(False)
        # ax.axhspan(2, 29.2, facecolor='r', alpha=0.1)
        # ax.axhspan(29.2, 40, facecolor='r', alpha=0.2)
        # ax.axhspan(40, 51.1, facecolor='r', alpha=0.3)
        # ax.axhspan(51.1, 61.1, facecolor='r', alpha=0.4)
        # ax.axhspan(61.1, 100, facecolor='r', alpha=0.5)

        # 设置legend颜色
        leg = ax.legend(fontsize=18, prop=zhfont, framealpha=0)
        for text in leg.get_texts():
            text.set_color('aqua')

        # 设置真实值所在的区间等级为橙色
        #==================================
        tt = fig_data[y_index]
        color = ['w', 'w', 'w', 'w', 'w']
        if tt <= 24:
            color[0] = 'orange'
        elif tt > 24 and tt <= 32:
            color[1] = 'orange'
        elif tt > 32 and tt <= 45:
            color[2] = 'orange'
        elif tt > 45 and tt <= 68.79:
            color[3] = 'orange'
        elif tt > 68.79:
            color[4] = 'orange'

        plt.show()
        # 设置双坐标轴
        #==================================
        ax2 = ax.twinx()
        ax2 = set_aex(ax2)

        ax2.set_ylim(0, 100)
        ind = [24, 32, 45, 68.79]
        #ind = [34, 42, 49, 61] #100档分组
        #ind = [i*22.5+5 for i in ind]
        ax2.yaxis.grid(True, color='aqua', linestyle='dashed', zorder=0)
        if not j == '年龄':
            ax2.annotate(r"低", xy=(figure[i][0]+0.1, ind[0]/2),color=color[0],size=15, fontproperties=zhfont)
            ax2.annotate(r"稍低", xy=(figure[i][0]+0.1, (ind[0]+ind[1])/2),color=color[1],size=15, fontproperties=zhfont)
            ax2.annotate(r"正常", xy=(figure[i][0]+0.1, (ind[2]+ind[1])/2),color=color[2],size=15, fontproperties=zhfont)
            ax2.annotate(r"稍高", xy=(figure[i][0]+0.1, (ind[2]+ind[3])/2),color=color[3],size=15, fontproperties=zhfont)
            ax2.annotate(r"高", xy=(figure[i][0]+0.1, (ind[3]+100)/2),color=color[4],size=15,fontproperties=zhfont)
        else:
            ax2.annotate(r"低", xy=(figure[i][0]+1, ind[0]/2),color=color[0],size=15, fontproperties=zhfont)
            ax2.annotate(r"稍低", xy=(figure[i][0]+1, (ind[0]+ind[1])/2),color=color[1],size=15, fontproperties=zhfont)
            ax2.annotate(r"正常", xy=(figure[i][0]+1, (ind[2]+ind[1])/2),color=color[2],size=15, fontproperties=zhfont)
            ax2.annotate(r"稍高", xy=(figure[i][0]+1, (ind[2]+ind[3])/2),color=color[3],size=15, fontproperties=zhfont)
            ax2.annotate(r"高", xy=(figure[i][0]+1, (ind[3]+100)/2),color=color[4],size=15,fontproperties=zhfont)

        ax2.set_yticks(ind)
        ax2.set_yticklabels(('', '', '', ''), fontsize=16)
        plt.subplots_adjust(left=0.1, wspace=0.25, hspace=0.25, bottom=0.13, top=0.91)


        out = str(sample_ID) + '-' + str(factor2[i]) + '.png'
        out2 = os.path.join(output, out)
        plt.savefig(out2, bbox_inches='tight', transparent=True, dpi=300)
        image[j] = {'title': factor[i], 'url': out2}
        plt.clf()
        flag += len(x)
        plt.close('all')
    mm = report.report(testfile, fig_data, cnf1, mm, avg_label, detect)
    mm['image'] = image
    #fig_data = fig_data.tolist()
    fig_data = [float('%.2f' % i) for i in fig_data]
    mm['fig_data'] = {'title': '作图数据', 'value': fig_data}
    #mm['fig_data'] = tt

    return mm




def factor_2_number(f, detect):
    '''将前端传来的信息量化成数字，返回模型所需的数据'''
    # gene1 = [0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    # gene2 = [2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]
    # gene3 = [2, 0, 2, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0]
    # gene4 = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

    cnf = '/home/gaobiyu/config/config.json'
    geno = '/home/gaobiyu/config/lc_upto0915.json'

    #load config file
    #==========================
    with open(geno, 'r') as f2:
        geno = json.load(f2)

    #load config file
    #==========================
    with open(cnf, 'r') as ff:
        cnf = json.load(ff)
    sample_ID = 'og00'
    if detect:
        try:
            sample_ID = f['条形码']
            #print(sample_ID)
            gene = geno[sample_ID]
        except:
            logger.info("条形码错误！您输入的条形码未找到，请重新输入！")
            sys.exit(1)
    else:
        gene = [random.randint(0, 2) for i in range(22)]

    fac = [["吸烟频率", "吸烟年限"],
           ["基本信息", "身高", "体重"],
           "摄入蔬菜水果频次",
           "摄入腌制蔬菜或烟熏肉类频次",
           "运动情况",
           ["基本信息", "地点"],
           "职业接触史",
           "肺癌家族史",
           ["基本信息", "年龄"],
           "肺部疾病史",
           "是否被动吸烟(二手烟)",
           ["基本信息", "性别"]]

    pp = cnf['lung_cancer']['ASQ']
    ps = cnf['lung_cancer']['city']


    smoke = pp[fac[0][0]][f[fac[0][0]]] * pp[fac[0][1]][f[fac[0][1]]]
    if smoke > 0 and smoke <= 100:
        smoke = 1
    elif smoke > 100 and smoke <= 200:
        smoke = 2
    elif smoke > 200 and smoke <= 300:
        smoke = 3
    elif smoke > 300 and smoke <= 400:
        smoke = 4
    elif smoke > 400:
        smoke = 5

    #print('smoke:',smoke, sep='\t')
    bmi = 10000* float(f[fac[1][0]][fac[1][2]]) /(float(f[fac[1][0]][fac[1][1]])**2)
    if bmi < 18.5:
        bmi = 0
    elif bmi >= 18.5 and bmi < 24:
        bmi = 1
    elif bmi >= 24 and bmi < 28:
        bmi = 2
    elif bmi >= 28 and bmi < 30:
        bmi = 3
    elif bmi >= 30 and bmi < 40:
        bmi = 4
    elif bmi >= 40:
        bmi = 5
    #print('BMI:', bmi, sep='\t')

    Gfood = pp[fac[2]][f[fac[2]]]
    Bfood = pp[fac[3]][f[fac[3]]]
    #print('Gfood:', Gfood, sep='\t')
    #print('Bfood:', Bfood, sep='\t')
    Sport = pp[fac[4]][f[fac[4]]]
    #print('Sport:', Sport, sep='\t')

    aqi = ps[f[fac[5][0]][fac[5][1]]] #暂定，不知省市是否分开
    if aqi > 0 and aqi <= 50:
        aqi = 1
    elif aqi > 50 and aqi <= 100:
        aqi = 2
    elif aqi > 100 and aqi <= 150:
        aqi = 3
    elif aqi > 150 and aqi <= 200:
        aqi = 4
    elif aqi > 200:
        aqi = 5
    #print('AQI:', aqi, sep='\t')


    if f[fac[6]] == "无以上接触":
        Job = 0
    elif len(f[fac[6]]) == 1 and f[fac[6]] != "无以上接触":
        Job = 4
    else:
        Job = 5
    #print('Job:', Job, sep='\t')

    family = pp[fac[7]][f[fac[7]]]
    #print('Family:', family, sep='\t')

    age = int(f[fac[8][0]][fac[8][1]])
    if age < 20:
        age = 20
    elif age > 80:
        age = 80

    #print('Age:', age, sep='\t')

    if f[fac[9]] == '无以上疾病':
        disease = 0
    else:
        disease = 1
    #print('Disease:', disease, sep='\t')

    sec_smoke = pp[fac[10]][f[fac[10]]]
    #print('Sec_smoke:', sec_smoke, sep='\t')

    sex = pp[fac[11][0]][fac[11][1]][f[fac[11][0]][fac[11][1]]]
    #print('Sex:', sex, sep='\t')

    testdata = [sample_ID] + gene + [smoke, bmi, Gfood, Bfood, Sport, aqi, Job, family, age, disease, sec_smoke, sex]
    return testdata
