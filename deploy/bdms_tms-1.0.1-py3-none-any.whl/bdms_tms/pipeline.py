# -*- coding: utf-8 -*-
#
# Created by lixing1611 on 17-4-5
#
from __future__ import absolute_import, unicode_literals
from sh import Command
from bdms_tms.tms import app

"""
Pipeline Modules: you can custom you pipeline here.
"""


# @app.task
def snp_anno(input_vcf, out_dir):
    command = Command(app.conf.get('snp_anno_path'))
    return command(input_vcf, out_dir)