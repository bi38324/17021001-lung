# -*- coding: utf-8 -*-
# created on 8/30/2017
# Author : Thomas
# Email  : tangyaohua1606@1gene.com.cn

from __future__ import absolute_import, unicode_literals
from celery.utils.log import get_task_logger
import time, os, json
import numpy as np

import bdms_tms.algorithms.lung_cancer_tester_2C_100level.src.main_plot as mp

from bdms_tms.tms import app
from bdms_tms.tms import TMS

"""
肺癌单页训练模型
"""


logger = get_task_logger(__name__)


class Tester(app.Task, TMS):
    """
    本流程为肺癌模型流程，基于输入的数据生成模型保存地址
     """
    __title__ = 'Lung cancer model trainer'
    __version__ = 'V1.0'
    __source_code__ = 'bdms_tms/algorithms/lung_cancer_tester/test_TMS.py'
    __params__ = \
    {
        'f':
        {
            'verbose': 'Item Data File',
            'required': True,
            'type': 'string',
            'default': None,
            'chinese_name': '分析样本',
            'discription': '需分析肺癌患病风险的样本数据集'
        },
        'sample_ID':
            {
                'verbose': 'User ID',
                'required': True,
                'type': 'string',
                'default': None,
                'chinese_name': '用户ID',
                'discription': '用户的编号，必须唯一，不能重复，分析结果以此ID为前缀'
            },
        'model_path':
        {
            'verbose': 'Model path',
            'required': True,
            'type': 'string',
            'default': None,
            'chinese_name': '模型地址',
            'discription': '保存模型的地址，用于模型重载，预测样本肺癌风险'
        },
        'model_acc':
            {
                'verbose': 'Model Accuracy',
                'required': False,
                'type': 'float',
                'default': 0.82,
                'chinese_name': '模型准确率',
                'discription': '用于预测样本肺癌风险的模型的准确率最小值，即高于该准确率的模型才会用于计算样本的肺癌风险'
            }
}

    def __init__(self):
        super(Tester, self).__init__()

    def run(self,
            f,
            model_path='/p299/user/og00/dev/pipe/workflow/01.lungcancer/model_dir/GH-LungCancer_lr_0.01-20170928-141857/',
            model_acc=0,
            detect=False):

        logger.info('运行肺癌单页模型训练流程: \n\tData_file:%s' % f)
        self.connect()
        self.get_fs()
        try:
            ss = mp.factor_2_number(f, detect)
            #print(ss)
            logger.info('From file to list, done')
            sample_ID = f['样本编号']
            #print(sample_ID,sss)
            mm = mp.main(
                testfile=ss,
                model_path=model_path,
                model_acc=model_acc,
                sample_ID=sample_ID,
                detect=detect)

            return mm

        finally:
            self.close()

start = time.time()
lung_cancer = app.register_task(Tester())
# load config file
# ==========================
# with open('samp.json', 'r') as ff:
#     f = json.load(ff)
# s = lung_cancer(f)
# with open('images.json', 'w') as o:
#     print(json.dumps(s, indent=4, ensure_ascii=False, sort_keys=True), file=o)
#
# finish = time.time()-start
# print(finish)