# -*- coding: utf-8 -*-
#
# Created by lixing1611 on 17-4-5
#
from __future__ import absolute_import, unicode_literals, division
import re
import csv
import json

from bdms_tms.tms import TMS


"""
算法模块
"""


class LogicRegressionAlgorithm(TMS):
    """
    Logic Regression算法
    """

    __params__ = {
        'p_attr_risk': 'Population Attribute Risk',
        'config_path': 'Configuration Path',
        'sample_dataset': 'Sample Dataset',
    }

    def __init__(self, p_attr_risk, config_path, sample_dataset):
        super(LogicRegressionAlgorithm, self).__init__()
        self.p_attr_risk = p_attr_risk
        self.config_path = config_path
        self.sample_dataset = sample_dataset
        self.b2 = {}
        self.ir = {}

    def read_config(self):
        with open(self.config_path) as f:
            reader = csv.reader(f, delimiter='\t')

            for row in reader:
                if row[0][0].isdigit():
                    age = int(re.split(r'[-+]', row[0]))
                    self.b2[age] = {'men': int(row[2])/100000, 'women': int(row[4])/100000}
                    self.ir[age] = {'men': int(row[1]), 'women': int(row[3])}
        return self.b2, self.ir

    def read_sample_dataset(self):
        self.connect()
        self.get_fs()
        f = self.fs.find({'filename': self.sample_dataset})
        sample_dataset = json.loads(f)

        for sample in sample_dataset:
            pass
        self.close()


if __name__ == '__main__':
    import sys
    import time

    for i in range(5):
        print('hello')
        sys.stdout.write('{0}/5\r'.format(i + 1))
        sys.stdout.flush()
        time.sleep(1)